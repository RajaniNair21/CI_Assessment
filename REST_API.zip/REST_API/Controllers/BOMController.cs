﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace REST_API.Controllers
{
    public class BOMController : ApiController
    {
        /// <summary>  
        /// Get Configuration details 
        /// </summary>  
        /// <param name="filter">filter</param>  
        /// <returns>Hierarchichal records based on part number</returns>  
        [HttpGet]
        public IHttpActionResult GetConfigurationsByPartNumber()
        {
            try
            {
                using (AssessmentEntities entities = new AssessmentEntities())
                {
                    //Testing.
                    //Group join to fetch records from Bom and Configuration tables.To get a sample JSON for binding.
                    //The below code will be replaced by invoking an SP(containing a recursive CTE) from the DAL layer.
                    var result = from c in entities.Configurations
                                 join b in entities.Boms
                                 on c.Id equals b.C__id into bGroup
                                 select new
                                 {
                                     ID = c.Id,
                                     PartNumber = c.PartNo,
                                     Description = c.Description,
                                     Details = bGroup

                                 };
                    if (result.Any())
                    {
                        var result1 = result.Select(x => x.Details).ToList();

                        if (result1 != null)
                        {
                            return Ok(result1);
                        }


                    }
                    return Content(HttpStatusCode.NotFound, "Configuration not found");

                }
            }
            catch (Exception ex)
            {
                return Content(HttpStatusCode.BadRequest, ex);

            }
        }

        ///// <summary>  
        ///// Get Configuration details by File Names
        ///// </summary>  
        ///// <param name="filter">filter</param>  
        ///// <returns>Hierarchichal records based on File names</returns>  
        //[HttpGet]
        //public IHttpActionResult GetConfigurationsByFileNames()
        //{
        //    try
        //    {
        //        using (AssessmentEntities entities = new AssessmentEntities())
        //        {
        //            //Testing
        //            //Group join to fetch records from Bom and Configuration tables
        //            var result = from c in entities.Configurations
        //                         join b in entities.Boms
        //                         on c.Id equals b.C__id into bGroup
        //                         select new
        //                         {
        //                             FileName = c.FilePath,
        //                             Details = bGroup

        //                         };
        //            if (result.Any())
        //            {
        //                var result1 = result.Select(x => x.Details).ToList();

        //                if (result1 != null)
        //                {
        //                    return Ok(result1);
        //                }


        //            }
        //            return Content(HttpStatusCode.NotFound, "Configuration not found");

        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return Content(HttpStatusCode.BadRequest, ex);

        //    }
        //}

    }


}



