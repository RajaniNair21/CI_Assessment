﻿using System;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using System.Collections.ObjectModel;
using Microsoft.Win32;

namespace CI_Solutions
{
    public class Helper
    {
        /// <summary>
        /// Parse the Incoming JSON to XML format.
        /// </summary>
        public static XDocument ParseJSONtoXML(string JSONContent)
        {
            return XDocument.Load(JsonReaderWriterFactory.CreateJsonReader(
                Encoding.ASCII.GetBytes(JSONContent), new XmlDictionaryReaderQuotas()));
        }

        public static XNode GetXMLFromJSON(string JSONContent)
        {
            XNode node = JsonConvert.DeserializeXNode(JSONContent, "Root");
            return node;
        }

        public static string ParseJSON(string JSONfilePath)
        {
            using (StreamReader r = new StreamReader(JSONfilePath))
            {
                return r.ReadToEnd();
                //string json = r.ReadToEnd();
                //List<Configuration> items = JsonConvert.DeserializeObject<List<Configuration>>(json);
                //lvConfigs.ItemsSource = items;
            }
        }

        public static void ExportJSON(string json)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "json files (*.json)|*.json";
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == true)
            {
                File.WriteAllText(saveFileDialog.FileName, json);
            }
        }
    }
}
