﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CI_Solutions.Model
{
    public class Configurations 
    {
      
        private string id;
        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        private string quantity;
        public string Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        private string description;
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

    }
}
