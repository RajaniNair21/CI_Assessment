﻿using CI_Solutions.Commands;
using CI_Solutions.Model;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Windows.Input;

namespace CI_Solutions.ViewModel
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        public RelayCommand ExportJSONCommand { get; set; }
        public RelayCommand IsPartNumberCheckedCommand { get; set; }
        public RelayCommand IsFileNameCheckedCommand { get; set; }

        private TabContentUserControlViewModel userControlInstance;

        public TabContentUserControlViewModel UserControlInstance
        {
            get { return userControlInstance; }
            set { userControlInstance = value; }
        }


        private bool isPartNumberChecked;

        public bool IsPartNumberChecked
        {
            get { return isPartNumberChecked; }
            set { isPartNumberChecked = value; OnPropertyChanged("IsPartNumberChecked"); }
        }

        private bool isFileNamesChecked;

        public bool IsFileNamesChecked
        {
            get { return isFileNamesChecked; }
            set { isFileNamesChecked = value; OnPropertyChanged("IsFileNamesChecked"); }
        }

        private bool PartNumberCanExecute(object arg)
        {
            return true;
        }

        private void PartNumberExecute(object obj)
        {
            if(UserControlInstance != null)
            {
                LoadListViewData(UserControlInstance);
                
            }
        }

        private bool FileNameCanExecute(object arg)
        {
            return true;
        }

        private void FileNameExecute(object obj)
        {
            if (UserControlInstance != null)
            {
                LoadListViewData(UserControlInstance);
            }
        }

        private bool ExportJSONCanExecute(object arg)
        {
            return true;
        }

        private void ExportJSONExecute(object obj)
        {
            if (this.UserControlInstance != null)
            {
                UserControlInstance.ExportJSON();
            }
        }

        public TabViewModel TabViewModelInstance { get; set; }


        // // Declare the event
        public event PropertyChangedEventHandler PropertyChanged;

        
        // // Create the OnPropertyChanged method to raise the event
        // // The calling member's name will be used as the parameter.
        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }


        public MainWindowViewModel()
        {
                ExportJSONCommand = new RelayCommand(ExportJSONExecute, ExportJSONCanExecute);
                IsPartNumberCheckedCommand = new RelayCommand(PartNumberExecute, PartNumberCanExecute);
                IsFileNameCheckedCommand = new RelayCommand(FileNameExecute, FileNameCanExecute);

                TabViewModelInstance = new TabViewModel();
                TabContentUserControlViewModel tbUCVM = new TabContentUserControlViewModel();
                this.UserControlInstance = tbUCVM;
                tbUCVM.MainWindowViewModelInstance = this;
                IsPartNumberChecked = true;
                //LoadListViewData(tbUCVM);
                //TESTING. Call the WebAPI method from here to load the data.
                var ConfigDetails = WebAPI.GetCall(Constants.BASE_URI + "BOM");
                if (ConfigDetails.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                

                }
        }

        public void LoadListViewData(TabContentUserControlViewModel uc)
        {
            uc.LoadListViewData();
        }
    }
}
