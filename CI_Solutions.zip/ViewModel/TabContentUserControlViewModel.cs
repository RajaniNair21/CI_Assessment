﻿using CI_Solutions.Model;
using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows.Data;

namespace CI_Solutions.ViewModel
{
    public class TabContentUserControlViewModel : INotifyPropertyChanged
    {
        private static readonly object ItemsLock = new object();

        public TabContentUserControlViewModel()
        {
            string JSONcontent = string.Empty;
            JSONcontent = Helper.ParseJSON("SampleDataPartNumber.json");
            Configs = JsonConvert.DeserializeObject<ObservableCollection<Configurations>>(JSONcontent);
            BindingOperations.EnableCollectionSynchronization(Configs, ItemsLock);


        }
        private Configurations _config;

        public Configurations Config
        {
            get { return _config; }
            set { _config = value; NotifyPropertyChanged("Config"); }
        }

        private ObservableCollection<Configurations> _configs;

        public ObservableCollection<Configurations> Configs
        {
            get { return _configs; }
            set { _configs = value; NotifyPropertyChanged("Configs"); }
        }


        private MainWindowViewModel mainWindowViewModelInstance;

        public MainWindowViewModel MainWindowViewModelInstance
        {
            get { return mainWindowViewModelInstance; }
            set { mainWindowViewModelInstance = value; }
        }


        private string _header;
        public string Header
        {
            get { return _header; }
            set
            {
                //if (!_header.Equals(value))
                //{
                    _header = value;
                    NotifyPropertyChanged(Header);
                //}
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string property)
        {
            PropertyChangedEventHandler pc = PropertyChanged;
            if (pc != null)
            {
                pc(this, new PropertyChangedEventArgs(property));
            }
        }

        public void LoadListViewData()
        {
            string JSONcontent = string.Empty;
            string JSONfileName = string.Empty;
            if (MainWindowViewModelInstance != null)
            {
                if (MainWindowViewModelInstance.IsPartNumberChecked)
                {
                   JSONfileName = "SampleDataPartNumber.json";
                }
                //Display File Names against Item Name column
                else
                {
                    JSONfileName = "SampleDataFileNames.json";
                }
                JSONcontent = Helper.ParseJSON(JSONfileName);
                Configs.Clear();
                Configs = JsonConvert.DeserializeObject<ObservableCollection<Configurations>>(JSONcontent);
                
            }
        }

        public void ExportJSON()
        {
            var json = JsonConvert.SerializeObject(Configs);
            Helper.ExportJSON(json);
            
        }
    }
}
