﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CI_Solutions.ViewModel
{
    public class TabViewModel
    {
        public TabContentUserControlViewModel[] TabItems { get; set; }

        public TabViewModel()
        {
            TabItems = new TabContentUserControlViewModel[]
                {
                    new TabContentUserControlViewModel() {Header = "DEFAULT"},
                    new TabContentUserControlViewModel() {Header = "TANK CONTAINER"},
                    new TabContentUserControlViewModel() {Header = "STAND ASSEMBLY"}
                };
        }
    }
}
