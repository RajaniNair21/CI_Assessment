﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CI_Solutions
{
    public class Constants
    {
        public const string BASE_URI = "https://localhost:44326/api/";
    }
}
