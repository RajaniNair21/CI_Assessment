/****** Script for SelectTopNRows command from SSMS  ******/
CREATE PROCEDURE spGetConfigurationNames AS
BEGIN
SELECT DISTINCT
      [ConfigurationName]    
  FROM [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration]
  WHERE  [ConfigurationName] <> ''
  END