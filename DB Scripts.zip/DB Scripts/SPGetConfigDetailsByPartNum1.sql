CREATE PROCEDURE SPGetCOnfigDetailsByPartNum1
AS
BEGIN
WITH TopCTE (Id,PartNo,[Description])
AS
(
SELECT c.Id, c.PartNo, c.[Description] 
FROM [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
WHERE c.IsRoot = 1 AND c.IsActive = 1 
),
RootSiblings 
AS
(
SELECT Id,PartNo,[Description] from TopCTE 
UNION ALL
SELECT c.Id, c.PartNo, c.[Description] from RootSiblings
JOIN [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
ON c.Id = RootSiblings.Id
WHERE c.IsRoot = 1 AND c.IsActive = 0 
),
Children
AS
(
Select Id,PartNo,[Description] from TopCTE
UNION ALL
SELECT c.Id, c.PartNo, c.[Description] from Children
JOIN [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
ON c.Id = Children.Id
WHERE c.IsRoot = 0
)
--Outer Query
--SELECT DISTINCT Id,PartNo,[Description] FROM RootSiblings
--UNION 
--SELECT DISTINCT Id, PartNo,[Description] FROM Children


SELECT DISTINCT Id,PartNo,[Description] FROM RootSiblings
UNION 
SELECT DISTINCT Id, PartNo,[Description] FROM Children
JOIN [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Bom] b
ON b.__id = Children.Id
END

