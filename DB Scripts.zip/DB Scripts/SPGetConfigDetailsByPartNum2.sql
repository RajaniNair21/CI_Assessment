CREATE PROCEDURE SPGetCOnfigDetailsByPartNum2
AS
BEGIN
With TOPCTE(Id, PartNo,[Description],[Level])
AS (
SELECT Id, PartNo,[Description],1 
FROM [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
WHERE IsRoot = 1 AND IsActive = 1
UNION ALL
SELECT c.Id,c.PartNo,c.[Description], TOPCTE.[Level] +1 FROM
[__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
JOIN TOPCTE
ON c.Id = TOPCTE.Id --WHERE IsActive = 0
),
RANKED AS (
SELECT Id,PartNo,[Description], MAX([Level]) AS [Level] from TOPCTE
GROUP BY Id,PartNo,[Description]
)
SELECT TOPCTE.Id,TOPCTE.PartNo, TOPCTE.[Description],b.Qty
FROM TOPCTE join RANKED r
ON TOPCTE.Id = r.Id AND TOPCTE.[Level] = r.[Level]
JOIN [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Bom] b
ON b.__id = TOPCTE.Id
END

