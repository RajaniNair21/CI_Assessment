WITH TopCTE
     (Id,PartNo,[Description])
AS
(
--Root and its Siblings
SELECT c.Id,c.PartNo,c.[Description]  FROM [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
where c.IsRoot = 1 
--AND c.IsActive = 1 
UNION ALL
--Children
SELECT c.Id,c.PartNo,c.[Description] FROM [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Configuration] c
            INNER JOIN TopCTE
                       ON TopCTE.Id = c.Id
					   where c.IsRoot = 0
				   
)
--OuterQuery
SELECT b.Qty, b.ParentConfigIndex, b.ChildConfigIndex,
       TopCTE.Id, TopCTE.PartNo, TopCTE.[Description]
			FROM TopCTE
            LEFT JOIN [__Assessment__].[2123__637328370661132736__SolidWorksNative].[Bom] b
			ON b.__id = TopCTE.Id;
